﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Collections;
using System.Linq;

namespace control2_Lunes
{
    public partial class PRUEBAS : Form
    {
        public PRUEBAS()
        {
            InitializeComponent();
        }
    }
}
